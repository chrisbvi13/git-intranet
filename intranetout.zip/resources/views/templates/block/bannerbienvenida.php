
<div class="grid-container">
  <div class="cell"><img src="images/welcome.jpg"/></div>
</div>