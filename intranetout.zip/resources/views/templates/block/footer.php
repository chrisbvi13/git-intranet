
<footer class="grid-y footercf align-center">
  <div class="grid-x align-center">
    <div class="cell small-4"><img class="img__footer" src="images/footerLogo.png"/></div>
    <div class="cell small-4 text-center align-self-middle">
      <div class="grid-y">
        <div class="cell paragraph__intranet">Intranet Cafesalud EPS</div>
        <div class="cell paragraph__gerencia">Gerencia TIC's</div>
      </div>
    </div>
  </div>
</footer>